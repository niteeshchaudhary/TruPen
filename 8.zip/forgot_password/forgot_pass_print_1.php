<!DOCTYPE html>
<html lang="en" >

<head>

  <meta charset="UTF-8">
  
<link rel="apple-touch-icon" type="image/png" href="" />
<meta name="apple-mobile-web-app-title" content="CodePen">

<link rel="shortcut icon" type="image/x-icon" href="" />
<link rel="mask-icon" type="" href="" color="#111" />


  <title>CodePen - Head for the Hills</title>
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  <!-- <link rel="stylesheet" href="../globalstyles.css">-->
  
<style>
  body {
    background: #fff;
    overflow: hidden;
    --orange: #ff7b0a;
    --pink: #fe3a7d;
    --gray: #ccc;
  }
  .logo {
      display: flex;
      align-items: center;
      font-weight: 600;
      font-size: 18px;
      cursor: pointer;
  }
  .logo svg {
      width: 24px;
      margin-right: 12px;
  }
  .header {
      display: flex;
      align-items: center;
      transition: box-shadow 0.3s;
      flex-shrink: 0;
      padding: 0 40px;
      white-space: nowrap;
      background-color: rgba(255, 255, 255, 1);
      height: 60px;
      font-size: 14px;
      justify-content: space-between;
  }
  .header-menu a {
      text-decoration: none;
      color: var(--body-color);
      font-weight: 500;
  }
  .header-menu a:hover {
      color: var(--active-color);
  }
  .header-menu a:not(:first-child) {
      margin-left: 30px;
  }
  .header-menu a.active {
      color: var(--active-color);
  }
  .user-settings {
      display: flex;
      align-items: center;
      font-weight: 500;
  }
  .user-settings svg {
      width: 20px;
      color: #94949f;
  }

  .user-menu {
      position: relative;
      margin-right: 8px;
      padding-right: 8px;
      border-right: 2px solid #d6d6db;
  }
  .user-menu:before {
      position: absolute;
      content: "";
      width: 7px;
      height: 7px;
      border-radius: 50%;
      border: 2px solid var(--header-bg-color);
      right: 6px;
      top: -1px;
      background-color: var(--active-color);
  }
  @keyframes AnimationName {
    0% {
        background-position: 0% 50%
    }
    50% {
        background-position: 100% 50%
    }
    100% {
        background-position: 0% 50%
    }
}
  .mbd {
    display: flex;
    justify-content: center;
    align-items: center;
    background: linear-gradient(270deg, #4285f4, #7542f4, #eb42f4);
    background-size: 400% 400%;
    -webkit-animation: AnimationName 4s ease infinite;
    -moz-animation: AnimationName 4s ease infinite;
    animation: AnimationName 4s ease infinite;
    height: 80vh;
    overflow: hidden;
    --orange: #ff7b0a;
    --pink: #fe3a7d;
    --gray: #ccc;
  }

  .mbd #wrap {
    position: relative;
    display: inline-block;
    height: 70px;
    font-family: "Lato";
    width: calc(100% - 400px);
    max-width: 750px;
    min-width: 350px;
  }
  .mbd #wrap:after {
    content: "";
    position: absolute;
    background: url("../Image_Components/running.png");
    background-position: 0px 50%;
    -webkit-animation: runner 0.5s steps(32, end) infinite;
            animation: runner 0.5s steps(32, end) infinite;
    opacity: 0;
  }
  .mbd #wrap.plunge {
    pointer-events: none;
  }
  .mbd #wrap.plunge input[type=email] {
    color: transparent;
  }
  .mbd #wrap.plunge .btnwrap .spark {
    -webkit-animation: spark 0.3s ease-in-out 1 forwards;
            animation: spark 0.3s ease-in-out 1 forwards;
  }
  @-webkit-keyframes spark {
    0% {
      transform: rotate(45deg) scale(0);
    }
    50% {
      transform: rotate(135deg) scale(1);
    }
    100% {
      transform: rotate(45deg) scale(0);
    }
  }
  @keyframes spark {
    0% {
      transform: rotate(45deg) scale(0);
    }
    50% {
      transform: rotate(135deg) scale(1);
    }
    100% {
      transform: rotate(45deg) scale(0);
    }
  }
  .mbd #wrap.plunge .btnwrap .spark:nth-of-type(1) {
    -webkit-animation-delay: 2.1s;
            animation-delay: 2.1s;
  }
  .mbd #wrap.plunge .btnwrap .spark:nth-of-type(2) {
    -webkit-animation-delay: 2.2s;
            animation-delay: 2.2s;
  }
  .mbd #wrap.plunge .btnwrap .spark:nth-of-type(3) {
    -webkit-animation-delay: 2.3s;
            animation-delay: 2.3s;
  }
  .mbd #wrap.plunge .btnwrap .spark:nth-of-type(4) {
    -webkit-animation-delay: 2.4s;
            animation-delay: 2.4s;
  }
  .mbd #wrap.plunge .btnwrap .spark:nth-of-type(5) {
    -webkit-animation-delay: 2.5s;
            animation-delay: 2.5s;
  }
  .mbd #wrap.plunge .btnwrap .spark:nth-of-type(6) {
    -webkit-animation-delay: 2.6s;
            animation-delay: 2.6s;
  }
  .mbd #wrap.plunge .btnwrap .blob {
    left: 20px;
    -webkit-animation: puff 0.5s ease-in-out 1 forwards;
            animation: puff 0.5s ease-in-out 1 forwards;
    -webkit-animation-delay: 1.65s;
            animation-delay: 1.65s;
    transform-origin: right;
  }
  @-webkit-keyframes puff {
    0% {
      left: 20px;
      transform: scale(1);
    }
    50% {
      left: calc(100% - 50px);
      transform: scale(1.15);
    }
    100% {
      left: calc(100% - 50px);
      transform: scale(0);
    }
  }
  @keyframes puff {
    0% {
      left: 20px;
      transform: scale(1);
    }
    50% {
      left: calc(100% - 50px);
      transform: scale(1.15);
    }
    100% {
      left: calc(100% - 50px);
      transform: scale(0);
    }
  }
  .mbd #wrap.plunge .btnwrap b:after {
    -webkit-animation: openclose 2.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) 1 forwards;
            animation: openclose 2.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) 1 forwards;
  }
  @-webkit-keyframes openclose {
    0% {
      transform: rotate(0deg);
    }
    10% {
      transform: rotate(120deg);
    }
    75% {
      transform: rotate(120deg);
      -webkit-animation-timing-function: ease-in;
              animation-timing-function: ease-in;
    }
    80% {
      -webkit-animation-timing-function: ease-in;
              animation-timing-function: ease-in;
      transform: rotate(0deg);
    }
    100% {
      -webkit-animation-timing-function: ease-in;
              animation-timing-function: ease-in;
      transform: rotate(0deg);
    }
  }
  @keyframes openclose {
    0% {
      transform: rotate(0deg);
    }
    10% {
      transform: rotate(120deg);
    }
    75% {
      transform: rotate(120deg);
      -webkit-animation-timing-function: ease-in;
              animation-timing-function: ease-in;
    }
    80% {
      -webkit-animation-timing-function: ease-in;
              animation-timing-function: ease-in;
      transform: rotate(0deg);
    }
    100% {
      -webkit-animation-timing-function: ease-in;
              animation-timing-function: ease-in;
      transform: rotate(0deg);
    }
  }
  .mbd #wrap.plunge .field {
    overflow: hidden;
    z-index: 999;
  }
  .mbd #wrap.plunge .field p .word .char {
    z-index: 2;
    -webkit-animation: run 2s ease-in 1 forwards;
            animation: run 2s ease-in 1 forwards;
    -webkit-animation-delay: 0.25s;
            animation-delay: 0.25s;
    will-change: transform;
  }
  @-webkit-keyframes run {
    to {
      transform: translateX(2000px);
    }
  }
  @keyframes run {
    to {
      transform: translateX(2000px);
    }
  }
  .mbd #wrap.plunge .field p .word .char:nth-of-type(2n) {
    -webkit-animation-duration: 2.25s;
            animation-duration: 2.25s;
  }
  .mbd #wrap.plunge .field p .word .char:nth-of-type(3n) {
    -webkit-animation-duration: 2.5s;
            animation-duration: 2.5s;
  }
  .mbd #wrap.plunge .field p .word .char:nth-of-type(4n) {
    -webkit-animation-duration: 2.15s;
            animation-duration: 2.15s;
  }
  .mbd #wrap.plunge .field p .word .char:nth-of-type(5n) {
    -webkit-animation-duration: 1.9s;
            animation-duration: 1.9s;
  }
  .mbd #wrap.plunge .field p .word .char:after {
    transition: 0.2s ease-in-out;
    transform: scale(0.75);
    z-index: -1;
  }
  .mbd #wrap .field {
    position: absolute;
    height: 70px;
    width: calc(100% - 180px);
    top: 50px;
    left: 50px;
    z-index: 9;
    pointer-events: none;
    font-size: 20px;
    font-family: "Lato";
    line-height: 1.5;
  }
  .mbd #wrap .field p {
    font-family: "Lato";
    position: relative;
    display: inline-block;
  }
  .mbd #wrap .field p .word .char {
    display: inline-block;
    z-index: 2;
    position: relative;
    font-family: "Lato";
    color: transparent;
    font-weight: 900;
  }
  .mbd #wrap .field p .word .char:nth-of-type(2n):after, body #wrap .field p .word .char:nth-of-type(2n):before {
    -webkit-animation-delay: -0.35s;
            animation-delay: -0.35s;
  }
  .mbd #wrap .field p .word .char:nth-of-type(2n):after, body #wrap .field p .word .char:nth-of-type(2n):before {
    -webkit-animation-delay: -0.15s;
            animation-delay: -0.15s;
  }
  .mbd #wrap .field p .word .char:nth-of-type(3n):after, body #wrap .field p .word .char:nth-of-type(3n):before {
    -webkit-animation-delay: -0.5s;
            animation-delay: -0.5s;
  }
  .mbd #wrap .field p .word .char:nth-of-type(4n) {
    -webkit-animation-duration: 1.75s;
            animation-duration: 1.75s;
  }
  .mbd #wrap .field p .word .char:nth-of-type(4n):after, body #wrap .field p .word .char:nth-of-type(4n):before {
    -webkit-animation-delay: -0.2s;
            animation-delay: -0.2s;
  }
  .mbd #wrap .field p .word .char:nth-of-type(1) {
    -webkit-animation-duration: 1.5s;
            animation-duration: 1.5s;
  }
  .mbd #wrap .field p .word .char:nth-of-type(1):after, body #wrap .field p .word .char:nth-of-type(1):before {
    -webkit-animation-delay: -0.15s;
            animation-delay: -0.15s;
  }
  .mbd #wrap .field p .word .char:before {
    content: attr(data-char);
    color: #000;
    display: inline-block;
    font-weight: 900;
    position: absolute;
    z-index: 2;
    -webkit-animation: bounce 0.25s ease-in-out infinite alternate;
            animation: bounce 0.25s ease-in-out infinite alternate;
    transform-origin: bottom;
  }
  @-webkit-keyframes bounce {
    from {
      transform: rotate(-13deg) skewX(-10deg);
    }
    to {
      transform: rotate(5deg) skewX(-15deg);
    }
  }
  @keyframes bounce {
    from {
      transform: rotate(-13deg) skewX(-10deg);
    }
    to {
      transform: rotate(5deg) skewX(-15deg);
    }
  }
  .mbd #wrap .field p .word .char:after {
    content: "";
    position: absolute;
    z-index: -1;
    width: 40px;
    height: 40px;
    bottom: -13px;
    left: calc(50% - 20px);
    transform-origin: top;
    width: 40px;
    height: 26px;
    background: url("../Image_Components/running.png");
    background-position: 0px 50%;
    -webkit-animation: runner 0.75s steps(32, end) infinite;
            animation: runner 0.75s steps(32, end) infinite;
    transform: scale(0);
    transition: 0.5s ease-in-out;
  }
  @-webkit-keyframes runner {
    from {
      background-position: 0px 50%;
    }
    to {
      background-position: -1280px 50%;
    }
  }
  @keyframes runner {
    from {
      background-position: 0px 50%;
    }
    to {
      background-position: -1280px 50%;
    }
  }
  .mbd #wrap form {
    position: relative;
    height: 70px;
    width: 100%;
    display: inline-block;
    z-index: 2;
  }
  .mbd #wrap form input[type=email] {
    max-height: 70px;
    height: 70px;
    width: calc(100% - 50px);
    padding: 0 0 0 50px;
    border-radius: 80px 0 0 80px;
    box-sizing: border-box;
    border: none;
    outline: none;
    font-size: 16px;
    font-family: "Lato";
    font-size: 20px;
    font-weight: 900;
  }
  .mbd #wrap form input[type=email]::-moz-placeholder {
    color: #ccc;
    font-weight: 100;
  }
  .mbd #wrap form input[type=email]:-ms-input-placeholder {
    color: #ccc;
    font-weight: 100;
  }
  .mbd #wrap form input[type=email]::placeholder {
    color: #ccc;
    font-weight: 100;
  }
  .mbd #wrap form .btnwrap {
    display: inline-block;
    width: auto;
    height: auto;
    position: absolute;
    right: 0;
    top: 0;
  }
  .mbd #wrap form .btnwrap .spark {
    position: absolute;
    width: 15px;
    height: 3px;
    background: linear-gradient(to right, var(--pink), var(--orange), var(--pink));
    top: -25px;
    border-radius: 100px;
    right: 10px;
    transform: rotate(45deg) scale(0);
  }
  .mbd #wrap form .btnwrap .spark:nth-of-type(4) {
    right: -50px;
    top: 0;
  }
  .mbd #wrap form .btnwrap .spark:nth-of-type(3) {
    right: -50px;
    top: 30px;
  }
  .mbd #wrap form .btnwrap .spark:nth-of-type(2) {
    right: -10px;
    top: 105px;
  }
  .mbd #wrap form .btnwrap .spark:nth-of-type(5) {
    right: 20px;
    top: 120px;
  }
  .mbd #wrap form .btnwrap .spark:nth-of-type(6) {
    right: -20px;
    top: -15px;
  }
  .mbd #wrap form .btnwrap .spark:before {
    content: "";
    position: absolute;
    width: 3px;
    height: 15px;
    background: linear-gradient(to bottom, var(--pink), var(--orange), var(--pink));
    top: calc(50% - 7.5px);
    left: calc(50% - 1.5px);
    border-radius: inherit;
  }
  .mbd #wrap form .btnwrap .blob {
    position: absolute;
    height: 70px;
    width: 70px;
    background: linear-gradient(to bottom, var(--orange), var(--orange) 30%, var(--pink) 70%);
    z-index: -1;
    border-radius: 100%;
    left: 20px;
    transform: scale(1);
  }
  .mbd #wrap form .btnwrap b {
    position: absolute;
    color: #fff;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: "Lato";
    letter-spacing: 1px;
    z-index: 2;
    font-size: 20px;
    pointer-events: none;
  }
  .mbd #wrap form .btnwrap b:before {
    content: "";
    position: absolute;
    width: calc(100% + 20px);
    height: 100%;
    background: linear-gradient(to bottom, var(--orange), var(--pink));
    z-index: -1;
    left: 0;
    border-radius: 0 80px 80px 0;
  }
  .mbd #wrap form .btnwrap b:after {
    content: "";
    position: absolute;
    width: 20px;
    height: 100%;
    left: -20px;
    background: linear-gradient(to bottom, var(--orange), var(--pink));
    border-radius: 0px 0 0 0px;
    transform-origin: 100% 0%;
    transition: 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    transition-delay: 1s;
    top: 0;
  }
  .mbd #wrap form input[type=submit] {
    height: 70px;
    border-radius: 80px;
    padding: 0 30px;
    border: none;
    opacity: 0;
  }
</style>

  <script>
  window.console = window.console || function(t) {};
</script>

  
  
  <script>
  if (document.location.search.match(/type=embed/gi)) {
    window.parent.postMessage("resize", "*");
  }
</script>


</head>

<body translate="no" >
  <header>
        <div class="header">
            <div class="logo">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="10 0 512 512" fill="#fff" style="visibility: visible;background-color:#99ffaa;border-radius:50%;">
                    <g transform="translate(0.000000,524.000000) scale(0.110000,-0.110000)" fill="#000000" stroke="none">
                        <path d="M3234 3848 c-7 -11 6 -28 64 -89 l43 -46 -40 -63 c-23 -35 -41 -71
                        -41 -81 0 -10 -13 -41 -30 -67 -34 -56 -36 -67 -14 -76 17 -7 34 0 34 14 0 5
                        5 21 11 37 l10 27 21 -33 21 -33 -41 -41 -42 -41 -33 32 c-18 18 -40 32 -48
                        32 -8 0 -97 -83 -198 -184 -131 -131 -182 -189 -178 -200 4 -9 14 -16 24 -16
                        10 0 93 75 185 167 167 166 167 167 188 148 21 -19 21 -19 -267 -307 l-288
                        -288 103 -102 102 -103 282 282 c195 194 291 283 308 285 18 2 25 9 25 24 0
                        13 24 47 56 81 31 32 59 69 63 81 9 27 18 28 33 2 12 -19 13 -19 65 5 28 13
                        75 27 104 31 48 6 52 8 58 36 3 17 6 48 6 69 l0 39 110 -7 c81 -4 110 -3 110
                        6 0 6 -72 92 -160 190 l-159 179 -123 6 c-233 11 -359 12 -364 4z"/>
                        <path d="M2544 2668 c-33 -35 -204 -356 -204 -383 0 -8 7 -18 16 -22 21 -8
                        349 160 392 201 l32 31 -103 103 -103 102 -30 -32z"/>
                        <path d="M1280 2525 l0 -65 -46 0 c-58 0 -111 -25 -129 -61 -22 -42 -22 -1006
                        0 -1048 31 -62 34 -62 574 -59 479 3 490 3 518 24 53 40 53 32 53 565 0 488 0
                        497 -21 523 -29 37 -71 56 -124 56 l-45 0 0 65 0 65 -65 0 -65 0 0 -65 0 -65
                        -260 0 -260 0 0 65 0 65 -65 0 -65 0 0 -65z m840 -750 l0 -355 -455 0 -455 0
                        0 355 0 355 455 0 455 0 0 -355z"/>
                        <path d="M1730 1845 l-155 -155 -67 67 -68 68 -35 -35 -35 -35 103 -103 102
                        -102 195 195 195 195 -35 29 c-19 17 -37 30 -40 31 -3 0 -75 -70 -160 -155z"/>
                        <path d="M3330 1519 c-371 -270 -675 -497 -674 -503 2 -17 184 -266 195 -266
                        17 0 1359 982 1358 993 0 15 -181 259 -194 264 -5 1 -314 -218 -685 -488z
                        m751 374 c34 -49 73 -102 86 -119 l23 -31 -652 -474 c-358 -261 -659 -480
                        -669 -486 -15 -11 -27 1 -105 109 l-88 121 29 25 29 24 20 -25 c12 -13 34 -42
                        50 -63 46 -59 43 -22 -3 40 -23 30 -41 57 -41 60 0 3 13 14 30 26 l30 21 25
                        -28 c27 -31 36 -13 10 23 -13 19 -12 23 15 42 16 12 33 22 38 22 5 0 28 -27
                        51 -60 23 -33 47 -58 52 -54 5 3 -11 35 -37 71 -49 69 -49 67 0 95 17 9 23 7
                        34 -11 8 -11 21 -21 29 -21 11 0 11 6 -4 31 l-18 31 29 23 29 23 51 -66 c27
                        -36 52 -60 54 -54 2 7 -15 37 -37 67 -23 30 -41 58 -41 62 0 4 12 17 28 29
                        l27 22 22 -26 c26 -33 42 -22 19 14 -17 24 -17 26 1 40 48 38 50 38 95 -26 40
                        -57 58 -73 58 -50 0 6 -19 36 -42 67 l-42 55 29 24 c37 30 39 30 55 -1 14 -25
                        30 -33 30 -15 0 6 -7 21 -15 34 -15 23 -15 25 14 45 16 12 33 21 38 21 5 0 29
                        -27 53 -60 24 -32 47 -57 52 -54 10 6 6 13 -45 81 l-39 53 23 20 c31 25 46 25
                        61 0 13 -20 38 -28 38 -11 0 5 -7 14 -15 21 -8 7 -15 18 -15 26 0 17 60 59 69
                        48 4 -5 24 -33 45 -61 33 -46 56 -66 56 -47 0 3 -20 34 -45 68 l-44 63 30 23
                        31 22 23 -28 c28 -34 45 -26 21 10 -22 34 -21 39 14 59 l29 18 43 -60 c24 -33
                        46 -61 51 -61 16 0 5 23 -34 76 -43 58 -42 71 3 95 14 8 23 4 43 -18 27 -31
                        34 -16 10 21 -15 22 -14 25 19 50 l34 26 47 -65 c25 -36 51 -63 56 -60 5 4
                        -12 35 -37 71 l-46 64 24 20 c12 11 28 19 34 20 7 0 40 -39 75 -87z"/>
                        <path d="M2727 1801 l-27 -6 40 -57 41 -57 55 6 c61 7 60 8 37 -54 -3 -7 -1
                        -13 4 -13 6 0 18 18 28 40 l18 39 -42 56 c-39 52 -44 55 -84 54 -23 -1 -54 -4
                        -70 -8z"/>
                        <path d="M3094 1705 c-48 -38 -54 -46 -38 -51 10 -4 41 -15 67 -26 l48 -18 47
                        36 47 36 5 -38 c3 -21 10 -39 17 -41 9 -3 10 7 6 34 -9 58 -17 67 -82 90 l-60
                        22 -57 -44z"/>
                        <path d="M2432 1589 c-29 -22 -52 -43 -52 -47 0 -5 28 -18 62 -30 67 -24 60
                        -26 131 28 l27 22 0 -25 c0 -32 9 -57 21 -57 12 0 0 82 -15 96 -6 7 -36 21
                        -67 32 l-55 20 -52 -39z"/>
                        <path d="M2707 1464 c-3 -4 11 -31 31 -60 l37 -54 58 2 c51 3 57 1 53 -14 -4
                        -10 -9 -27 -12 -38 -12 -38 14 -20 30 21 17 41 17 42 -9 78 -52 74 -48 71
                        -117 71 -36 0 -67 -3 -71 -6z"/>
                    </g>
                </svg>
                TruPen
            </div>
            <div class="header-menu">
            </div>
        </div>
    </header>
<div class="mbd">
  <div id='wrap'>
    <h3 style="color:white;">Enter Registered Email</h3>
  <div class='field'></div>
  <form class='signup'  method="POST" onsubmit="return validateForm()">
    <input class='email' placeholder='email' type='email' id="mailid" name="mailid" required>
    <div class='btnwrap'>
      <div class='spark'></div>
      <div class='spark'></div>
      <div class='spark'></div>
      <div class='spark'></div>
      <div class='spark'></div>
      <div class='spark'></div>
      <b>Submit</b>
      <div class='blob'></div>
      <input type='submit' value='Submit'>
    </div>
  </form>
</div>
</div>

<footer>
  <center><br>© Copyright TruPen.<br>All Rights Reserved</center>
</footer>
  <script src='../Design_Components/jquery.min.js'></script>
<script src='../Design_Components/splitting.min.js'></script>
<script>
  var emailText;
 /* function validateForm(){
    emailText = $('.email').val();
    $('.email').val('');
    $(".field").append("<p data-splitting='chars'>" + emailText + "</p>");
    Splitting();
    $("#wrap").addClass("plunge");
    setTimeout(function () {
      $(".field p").remove();
      $("#wrap").removeClass("plunge");
     }, 4000);
    $('.signup').submit(function (event) {
  //event.preventDefault();
  
      
});
    document.getElementById("mailid").value=emailText;
    let start = Date.now(); // remember start time
    setTimeout(function () {
        checkdb();
    }, 4000);
    
  }*/
  function validateForm(){
    
  }
  function vf(){
    checkdb();
  }

  function checkdb(){
          $.ajax({
                   type:"POST",
                   url: "forgot_pass_print_2.php",
                   data:{ "mailid": emailText},
                    success: function(msg){
                        if(msg.slice(-1)==2){
                          alert('Email sending failed... Try again');
                        }
                        else if(msg==0){
                          alert('Email Not in database');
                        }
                        else if(msg==1){
							$(location).prop('href', 'forgot_pass_print_3.php');
                        }
                    }
                 });
  }
  Splitting();

  $('.signup').submit(function (event) {
    event.preventDefault();
    emailText = $('.email').val();
    $('.email').val('');
    $(".field").append("<p data-splitting='chars'>" + emailText + "</p>");
    Splitting();
    $("#wrap").addClass("plunge");
    setTimeout(function () {
      checkdb();
      $('.email').val('');
      $(".field p").remove();
      $("#wrap").removeClass("plunge");
    }, 3500);
    
  });
</script>
</body>

</html>
 
