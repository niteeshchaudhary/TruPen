# truPen

SSL project a simple and easy user interface for quizzes / assignment submissions .

## Team members :

1. Tabish Khalid Halim
2. Shashank P
3. Niteesh Kamal Choudhary
